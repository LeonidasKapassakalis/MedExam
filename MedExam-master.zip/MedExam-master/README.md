Django Medical Examinations 
