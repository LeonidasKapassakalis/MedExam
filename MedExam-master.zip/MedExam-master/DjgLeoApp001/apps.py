from __future__ import unicode_literals

from django.apps import AppConfig


class Djgleoapp001Config(AppConfig):
    name = 'DjgLeoApp001'
